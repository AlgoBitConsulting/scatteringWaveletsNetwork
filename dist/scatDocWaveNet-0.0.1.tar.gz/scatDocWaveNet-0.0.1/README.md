# scatteringWaveletsNetworks
table detection in PDF and scaned documents with scattering wavelets

comming soon
