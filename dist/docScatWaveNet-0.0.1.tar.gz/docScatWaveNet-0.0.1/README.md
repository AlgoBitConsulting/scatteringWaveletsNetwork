# Example Package

table detection in PDF and scaned documents with scattering wavelets

python -m pip install --index-url https://test.pypi.org/simple/ --no-deps docScatWaveNet-markus2

python -m pip install --no-index packaging_tutorial/dist/docScatWaveNet_markus2-0.0.1-py3-none-any.whl

https://github.com/lrothack/dev-ops
